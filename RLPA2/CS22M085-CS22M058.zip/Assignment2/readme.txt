This folder contains the following

1. codebase folder -> inside which dqn and actor-critic folders which contains the code and the plotted graphs for the environments.
(All experiments are not added as that would make this a huge file)

2. sample pdf of the jupyter notebook with the code for dqn and actor critic. Actual notebooks are included in the codebase. As we ran each experiment in it's on notebook on Kaggle with only the hyperparameters changed, we included only one pdf for dqn and actor critic each

3. text file containing the name and roll numbers of the team members

4. report
